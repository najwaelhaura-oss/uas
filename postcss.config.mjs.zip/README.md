
  # K-Pop Merchandise E-Commerce

  This is a code bundle for K-Pop Merchandise E-Commerce. The original project is available at https://www.figma.com/design/ssKwDeNSjOVHUmKkbYMtQP/K-Pop-Merchandise-E-Commerce.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  