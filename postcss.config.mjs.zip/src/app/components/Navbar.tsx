import { Link, useLocation } from 'react-router-dom';
import { ShoppingCart, Home, MessageSquare, User, LogOut } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

export function Navbar() {
  const { user, cart, logout } = useApp();
  const location = useLocation();
  
  const isActive = (path: string) => location.pathname === path;
  
  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <div className="h-8 w-8 rounded-full bg-gradient-to-r from-purple-500 to-pink-500" />
          <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            K-PopVerse
          </span>
        </Link>

        {user && (
          <div className="flex items-center gap-6">
            <Link
              to="/"
              className={`flex items-center gap-2 transition-colors ${
                isActive('/') ? 'text-purple-600' : 'text-gray-600 hover:text-purple-600'
              }`}
            >
              <Home className="h-5 w-5" />
              <span className="hidden sm:inline">Beranda</span>
            </Link>

            <Link
              to="/forum"
              className={`flex items-center gap-2 transition-colors ${
                isActive('/forum') ? 'text-purple-600' : 'text-gray-600 hover:text-purple-600'
              }`}
            >
              <MessageSquare className="h-5 w-5" />
              <span className="hidden sm:inline">Forum</span>
            </Link>

            <Link
              to="/cart"
              className={`flex items-center gap-2 transition-colors relative ${
                isActive('/cart') ? 'text-purple-600' : 'text-gray-600 hover:text-purple-600'
              }`}
            >
              <ShoppingCart className="h-5 w-5" />
              {cartItemCount > 0 && (
                <Badge className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 bg-pink-500">
                  {cartItemCount}
                </Badge>
              )}
              <span className="hidden sm:inline">Keranjang</span>
            </Link>

            <div className="flex items-center gap-3 border-l pl-4">
              <div className="flex items-center gap-2">
                <User className="h-5 w-5 text-gray-600" />
                <span className="hidden md:inline text-sm text-gray-700">{user.name}</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={logout}
                className="gap-2"
              >
                <LogOut className="h-4 w-4" />
                <span className="hidden sm:inline">Keluar</span>
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
