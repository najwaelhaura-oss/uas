import { Link } from 'react-router-dom';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { CheckCircle, Package, Home, FileText, MapPin } from 'lucide-react';
import { motion } from 'motion/react';

export function OrderCompletePage() {
  const orderNumber = `KPV${Date.now().toString().slice(-8)}`;
  const estimatedDelivery = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toLocaleDateString('id-ID', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 py-12">
      <div className="container max-w-2xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="p-8 text-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
            >
              <CheckCircle className="h-20 w-20 text-green-500 mx-auto mb-4" />
            </motion.div>
            
            <h1 className="text-3xl font-bold mb-2">Pembayaran Berhasil!</h1>
            <p className="text-gray-600 mb-8">
              Terima kasih telah berbelanja di K-PopVerse
            </p>

            <div className="bg-gray-50 rounded-lg p-6 mb-6 text-left">
              <div className="grid gap-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">Nomor Pesanan</span>
                  <span className="font-bold">{orderNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Tanggal Pemesanan</span>
                  <span className="font-medium">
                    {new Date().toLocaleDateString('id-ID', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric'
                    })}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Estimasi Pengiriman</span>
                  <span className="font-medium">{estimatedDelivery}</span>
                </div>
              </div>
            </div>

            <div className="bg-purple-50 border border-purple-200 rounded-lg p-6 mb-8">
              <div className="flex items-start gap-4">
                <Package className="h-6 w-6 text-purple-600 flex-shrink-0 mt-1" />
                <div className="text-left">
                  <h3 className="font-semibold text-purple-900 mb-1">
                    Pesanan Anda sedang diproses
                  </h3>
                  <p className="text-sm text-purple-700">
                    Kami akan segera mengemas pesanan Anda. Notifikasi akan dikirim melalui email dan WhatsApp saat pesanan dikirim.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="grid sm:grid-cols-2 gap-3">
                <Link to={`/invoice?order=${orderNumber}`} className="block">
                  <Button variant="outline" className="w-full gap-2">
                    <FileText className="h-4 w-4" />
                    Lihat Invoice
                  </Button>
                </Link>
                <Link to={`/tracking?order=${orderNumber}`} className="block">
                  <Button variant="outline" className="w-full gap-2">
                    <MapPin className="h-4 w-4" />
                    Lacak Pesanan
                  </Button>
                </Link>
              </div>
              
              <Link to="/" className="block">
                <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                  <Home className="h-4 w-4 mr-2" />
                  Kembali ke Beranda
                </Button>
              </Link>
            </div>
          </Card>

          {/* Additional Info */}
          <div className="mt-8 space-y-4">
            <Card className="p-6">
              <h3 className="font-semibold mb-3">Apa Selanjutnya?</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-start gap-2">
                  <span className="text-purple-600 mt-0.5">✓</span>
                  <span>Konfirmasi pesanan telah dikirim ke email Anda</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-600 mt-0.5">✓</span>
                  <span>Pesanan akan diproses dalam 1-2 hari kerja</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-600 mt-0.5">✓</span>
                  <span>Anda akan menerima nomor resi saat pesanan dikirim</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-600 mt-0.5">✓</span>
                  <span>Estimasi pengiriman 2-4 hari kerja</span>
                </li>
              </ul>
            </Card>

            <div className="text-center text-sm text-gray-600">
              <p>
                Butuh bantuan? Hubungi customer service kami di{' '}
                <a href="mailto:cs@k-popverse.com" className="text-purple-600 hover:underline">
                  cs@k-popverse.com
                </a>
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}