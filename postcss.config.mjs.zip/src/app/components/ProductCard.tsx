import { ShoppingCart } from 'lucide-react';
import { Product } from '../context/AppContext';
import { Button } from './ui/button';
import { Card, CardContent, CardFooter } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ProductCardProps {
  product: Product;
  onAddToCart: () => void;
}

export function ProductCard({ product, onAddToCart }: ProductCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative aspect-square overflow-hidden bg-gray-100">
        <ImageWithFallback
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
        />
        <Badge className="absolute top-2 right-2 bg-purple-500">
          {product.category}
        </Badge>
      </div>
      
      <CardContent className="p-4">
        <div className="space-y-1">
          <p className="text-sm text-gray-600">{product.artist}</p>
          <h3 className="font-semibold line-clamp-2">{product.name}</h3>
          <p className="text-lg font-bold text-purple-600">
            Rp {product.price.toLocaleString('id-ID')}
          </p>
          <p className="text-xs text-gray-500">
            Stok: {product.stock} pcs
          </p>
        </div>
      </CardContent>
      
      <CardFooter className="p-4 pt-0">
        <Button
          onClick={onAddToCart}
          className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          disabled={product.stock === 0}
        >
          <ShoppingCart className="h-4 w-4 mr-2" />
          {product.stock === 0 ? 'Habis' : 'Tambah ke Keranjang'}
        </Button>
      </CardFooter>
    </Card>
  );
}
