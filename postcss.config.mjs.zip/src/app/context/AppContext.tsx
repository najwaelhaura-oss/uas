import React, { createContext, useContext, useState, ReactNode } from 'react';

export interface Product {
  id: number;
  name: string;
  artist: string;
  price: number;
  image: string;
  category: string;
  stock: number;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface ForumPost {
  id: number;
  author: string;
  avatar: string;
  group: string;
  title: string;
  content: string;
  likes: number;
  replies: number;
  timestamp: string;
}

interface AppContextType {
  user: { name: string; email: string } | null;
  cart: CartItem[];
  login: (email: string, password: string) => void;
  logout: () => void;
  addToCart: (product: Product) => void;
  removeFromCart: (productId: number) => void;
  updateQuantity: (productId: number, quantity: number) => void;
  clearCart: () => void;
  products: Product[];
  forumPosts: ForumPost[];
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
};

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<{ name: string; email: string } | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);

  // Mock products data
  const products: Product[] = [
    {
      id: 1,
      name: 'BTS Album - Proof',
      artist: 'BTS',
      price: 299000,
      image: 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?w=500&h=500&fit=crop',
      category: 'Album',
      stock: 50
    },
    {
      id: 2,
      name: 'BLACKPINK Lightstick',
      artist: 'BLACKPINK',
      price: 450000,
      image: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=500&h=500&fit=crop',
      category: 'Lightstick',
      stock: 30
    },
    {
      id: 3,
      name: 'TWICE Photocard Set',
      artist: 'TWICE',
      price: 150000,
      image: 'https://images.unsplash.com/photo-1611967728125-54d3f619e8b6?w=500&h=500&fit=crop',
      category: 'Photocard',
      stock: 100
    },
    {
      id: 4,
      name: 'EXO Concert T-Shirt',
      artist: 'EXO',
      price: 250000,
      image: 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=500&h=500&fit=crop',
      category: 'Apparel',
      stock: 75
    },
    {
      id: 5,
      name: 'Stray Kids Album - 5-STAR',
      artist: 'Stray Kids',
      price: 280000,
      image: 'https://images.unsplash.com/photo-1519682337058-a94d519337bc?w=500&h=500&fit=crop',
      category: 'Album',
      stock: 60
    },
    {
      id: 6,
      name: 'NewJeans Poster Set',
      artist: 'NewJeans',
      price: 120000,
      image: 'https://images.unsplash.com/photo-1615750185825-730f5c0c54e1?w=500&h=500&fit=crop',
      category: 'Poster',
      stock: 120
    },
    {
      id: 7,
      name: 'Seventeen Lightstick Ver.3',
      artist: 'Seventeen',
      price: 500000,
      image: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&h=500&fit=crop',
      category: 'Lightstick',
      stock: 40
    },
    {
      id: 8,
      name: 'LE SSERAFIM Hoodie',
      artist: 'LE SSERAFIM',
      price: 380000,
      image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=500&h=500&fit=crop',
      category: 'Apparel',
      stock: 55
    },
  ];

  // Mock forum posts data
  const forumPosts: ForumPost[] = [
    {
      id: 1,
      author: 'ARMY_Forever',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop',
      group: 'BTS',
      title: 'BTS comeback 2024 predictions!',
      content: 'What do you think BTS next album concept will be? I hope they go back to their hip-hop roots...',
      likes: 234,
      replies: 56,
      timestamp: '2 hours ago'
    },
    {
      id: 2,
      author: 'BlinkInYourArea',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      group: 'BLACKPINK',
      title: 'Best BLACKPINK live performance?',
      content: 'Their Coachella 2023 performance was absolutely legendary! What are your favorite live stages?',
      likes: 189,
      replies: 42,
      timestamp: '5 hours ago'
    },
    {
      id: 3,
      author: 'OnceUponATime',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
      group: 'TWICE',
      title: 'TWICE 8th Anniversary Appreciation',
      content: 'Cannot believe its been 8 years! They have grown so much as artists and performers. My favorite era is...',
      likes: 312,
      replies: 78,
      timestamp: '1 day ago'
    },
    {
      id: 4,
      author: 'StayWithMe',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      group: 'Stray Kids',
      title: 'Best Stray Kids B-side tracks?',
      content: 'Let\'s talk about underrated B-sides! "Silent Cry" and "RED LIGHTS" deserve more love!',
      likes: 156,
      replies: 34,
      timestamp: '3 hours ago'
    },
    {
      id: 5,
      author: 'NewJeansLover',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
      group: 'NewJeans',
      title: 'NewJeans is revolutionizing K-pop!',
      content: 'Their fresh sound and aesthetic is exactly what the industry needed. "OMG" was such a bop!',
      likes: 267,
      replies: 91,
      timestamp: '6 hours ago'
    },
  ];

  const login = (email: string, password: string) => {
    // Mock login - in real app, this would validate credentials
    setUser({ name: email.split('@')[0], email });
  };

  const logout = () => {
    setUser(null);
    setCart([]);
  };

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: number) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev =>
      prev.map(item =>
        item.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  return (
    <AppContext.Provider
      value={{
        user,
        cart,
        login,
        logout,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        products,
        forumPosts,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};
