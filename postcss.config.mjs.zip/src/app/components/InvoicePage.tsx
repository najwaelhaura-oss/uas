import { useSearchParams, useNavigate } from 'react-router-dom';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import { Download, Printer, ArrowLeft, Package } from 'lucide-react';
import { useApp } from '../context/AppContext';

export function InvoicePage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user, products } = useApp();
  
  const orderNumber = searchParams.get('order') || 'KPV12345678';
  const orderDate = new Date();
  const dueDate = new Date(Date.now() + 1 * 24 * 60 * 60 * 1000);

  // Mock invoice items - in real app, this would come from order data
  const invoiceItems = [
    {
      id: 1,
      name: products[0]?.name || 'BTS Album - Proof',
      artist: products[0]?.artist || 'BTS',
      quantity: 1,
      price: products[0]?.price || 299000
    },
    {
      id: 2,
      name: products[1]?.name || 'BLACKPINK Lightstick',
      artist: products[1]?.artist || 'BLACKPINK',
      quantity: 1,
      price: products[1]?.price || 450000
    }
  ];

  const subtotal = invoiceItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = 15000;
  const tax = Math.round(subtotal * 0.11); // PPN 11%
  const total = subtotal + shipping + tax;

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    // In real app, this would generate and download PDF
    alert('Fitur download PDF akan segera tersedia!');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 py-8">
      <div className="container max-w-4xl">
        {/* Action Buttons - Hidden on print */}
        <div className="flex items-center justify-between mb-6 print:hidden">
          <Button
            variant="outline"
            onClick={() => navigate(-1)}
            className="gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Kembali
          </Button>
          
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={handleDownload}
              className="gap-2"
            >
              <Download className="h-4 w-4" />
              Download PDF
            </Button>
            <Button
              onClick={handlePrint}
              className="gap-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              <Printer className="h-4 w-4" />
              Print
            </Button>
          </div>
        </div>

        {/* Invoice Card */}
        <Card className="p-8 md:p-12 print:shadow-none">
          {/* Header */}
          <div className="flex items-start justify-between mb-8">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="h-12 w-12 rounded-full bg-gradient-to-r from-purple-500 to-pink-500" />
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                    K-PopVerse
                  </h1>
                  <p className="text-sm text-gray-600">Official K-Pop Merchandise</p>
                </div>
              </div>
              <div className="text-sm text-gray-600 mt-4">
                <p>Jl. Sudirman No. 123</p>
                <p>Jakarta Pusat 10220</p>
                <p>Indonesia</p>
                <p className="mt-2">Email: cs@k-popverse.com</p>
                <p>Phone: +62 812-3456-7890</p>
              </div>
            </div>
            
            <div className="text-right">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">INVOICE</h2>
              <div className="text-sm space-y-1">
                <p>
                  <span className="text-gray-600">Invoice No:</span>{' '}
                  <span className="font-semibold">{orderNumber}</span>
                </p>
                <p>
                  <span className="text-gray-600">Tanggal:</span>{' '}
                  <span className="font-semibold">
                    {orderDate.toLocaleDateString('id-ID', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric'
                    })}
                  </span>
                </p>
                <p>
                  <span className="text-gray-600">Jatuh Tempo:</span>{' '}
                  <span className="font-semibold">
                    {dueDate.toLocaleDateString('id-ID', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric'
                    })}
                  </span>
                </p>
              </div>
            </div>
          </div>

          <Separator className="my-8" />

          {/* Bill To */}
          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Ditagih Kepada:</h3>
              <div className="text-sm text-gray-600">
                <p className="font-medium text-gray-900">{user?.name || 'Customer Name'}</p>
                <p>{user?.email || 'customer@email.com'}</p>
                <p className="mt-2">Jl. Merdeka No. 456</p>
                <p>Jakarta Selatan 12940</p>
                <p>Indonesia</p>
                <p className="mt-2">Phone: +62 821-9876-5432</p>
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Dikirim Ke:</h3>
              <div className="text-sm text-gray-600">
                <p className="font-medium text-gray-900">{user?.name || 'Customer Name'}</p>
                <p className="mt-2">Jl. Merdeka No. 456</p>
                <p>Jakarta Selatan 12940</p>
                <p>Indonesia</p>
                <p className="mt-2">Phone: +62 821-9876-5432</p>
              </div>
            </div>
          </div>

          {/* Items Table */}
          <div className="overflow-x-auto mb-8">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b-2 border-gray-300">
                  <th className="text-left py-3 font-semibold text-gray-900">Item</th>
                  <th className="text-center py-3 font-semibold text-gray-900 w-20">Qty</th>
                  <th className="text-right py-3 font-semibold text-gray-900 w-32">Harga</th>
                  <th className="text-right py-3 font-semibold text-gray-900 w-32">Total</th>
                </tr>
              </thead>
              <tbody>
                {invoiceItems.map((item, index) => (
                  <tr key={item.id} className="border-b border-gray-200">
                    <td className="py-4">
                      <div>
                        <p className="font-medium text-gray-900">{item.name}</p>
                        <p className="text-gray-600 text-xs mt-1">{item.artist}</p>
                      </div>
                    </td>
                    <td className="text-center py-4 text-gray-700">{item.quantity}</td>
                    <td className="text-right py-4 text-gray-700">
                      Rp {item.price.toLocaleString('id-ID')}
                    </td>
                    <td className="text-right py-4 font-medium text-gray-900">
                      Rp {(item.price * item.quantity).toLocaleString('id-ID')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totals */}
          <div className="flex justify-end">
            <div className="w-full md:w-80 space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Subtotal:</span>
                <span className="font-medium">Rp {subtotal.toLocaleString('id-ID')}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Ongkos Kirim:</span>
                <span className="font-medium">Rp {shipping.toLocaleString('id-ID')}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">PPN (11%):</span>
                <span className="font-medium">Rp {tax.toLocaleString('id-ID')}</span>
              </div>
              <Separator />
              <div className="flex justify-between">
                <span className="font-bold text-gray-900">Total:</span>
                <span className="font-bold text-xl text-purple-600">
                  Rp {total.toLocaleString('id-ID')}
                </span>
              </div>
            </div>
          </div>

          <Separator className="my-8" />

          {/* Payment Info */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-6 mb-8">
            <div className="flex items-center gap-3 mb-3">
              <div className="h-10 w-10 rounded-full bg-green-500 flex items-center justify-center">
                <Package className="h-5 w-5 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-green-900">Status Pembayaran</h3>
                <p className="text-sm text-green-700">Pembayaran Telah Diterima</p>
              </div>
            </div>
            <div className="text-sm text-green-700 space-y-1">
              <p>Metode Pembayaran: Kartu Kredit (**** 4242)</p>
              <p>Tanggal Pembayaran: {orderDate.toLocaleDateString('id-ID')}</p>
            </div>
          </div>

          {/* Notes & Terms */}
          <div className="space-y-6 text-sm">
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Catatan:</h3>
              <p className="text-gray-600">
                Terima kasih telah berbelanja di K-PopVerse! Pesanan Anda sedang diproses dan akan segera dikirim. 
                Anda akan menerima notifikasi email dengan nomor resi pengiriman.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Syarat & Ketentuan:</h3>
              <ul className="text-gray-600 space-y-1 list-disc list-inside">
                <li>Barang yang sudah dibeli tidak dapat dikembalikan kecuali ada cacat produksi</li>
                <li>Klaim kerusakan harus dilaporkan maksimal 2x24 jam setelah barang diterima</li>
                <li>Estimasi pengiriman 2-4 hari kerja tergantung lokasi</li>
                <li>Produk 100% original dan bergaransi resmi</li>
              </ul>
            </div>
          </div>

          <Separator className="my-8" />

          {/* Footer */}
          <div className="text-center text-sm text-gray-600">
            <p>Invoice ini digenerate secara otomatis oleh sistem K-PopVerse</p>
            <p className="mt-1">
              Untuk pertanyaan, hubungi: cs@k-popverse.com | WhatsApp: +62 812-3456-7890
            </p>
            <p className="mt-4 text-xs">
              © {new Date().getFullYear()} K-PopVerse. All rights reserved.
            </p>
          </div>
        </Card>

        {/* Track Order Button - Hidden on print */}
        <div className="mt-6 text-center print:hidden">
          <Button
            onClick={() => navigate(`/tracking?order=${orderNumber}`)}
            variant="outline"
            className="gap-2"
          >
            <Package className="h-4 w-4" />
            Lacak Pesanan
          </Button>
        </div>
      </div>
    </div>
  );
}
