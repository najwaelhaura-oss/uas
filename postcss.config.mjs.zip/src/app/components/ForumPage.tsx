import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Heart, MessageCircle, Search, Plus } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function ForumPage() {
  const { forumPosts } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGroup, setSelectedGroup] = useState('all');

  const groups = ['all', ...Array.from(new Set(forumPosts.map(p => p.group)))];

  const filteredPosts = forumPosts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.author.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesGroup = selectedGroup === 'all' || post.group === selectedGroup;
    return matchesSearch && matchesGroup;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 py-8">
      <div className="container max-w-5xl">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Forum Komunitas K-Pop</h1>
            <p className="text-gray-600">Diskusi, berbagi, dan terhubung dengan sesama K-Pop fans!</p>
          </div>
          <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
            <Plus className="h-4 w-4 mr-2" />
            Buat Post
          </Button>
        </div>

        {/* Search and Filter */}
        <div className="mb-6 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <Input
              type="text"
              placeholder="Cari diskusi..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            <Button
              variant={selectedGroup === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedGroup('all')}
              className={selectedGroup === 'all' ? 'bg-purple-600' : ''}
            >
              Semua
            </Button>
            {groups.filter(g => g !== 'all').map(group => (
              <Button
                key={group}
                variant={selectedGroup === group ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedGroup(group)}
                className={selectedGroup === group ? 'bg-purple-600' : ''}
              >
                {group}
              </Button>
            ))}
          </div>
        </div>

        {/* Forum Posts */}
        <div className="space-y-4">
          {filteredPosts.length > 0 ? (
            filteredPosts.map(post => (
              <Card key={post.id} className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex gap-4">
                  <Avatar className="h-12 w-12 flex-shrink-0">
                    <AvatarImage asChild>
                      <ImageWithFallback src={post.avatar} alt={post.author} />
                    </AvatarImage>
                    <AvatarFallback>{post.author[0]}</AvatarFallback>
                  </Avatar>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="font-semibold">{post.author}</span>
                      <Badge variant="secondary" className="text-xs">
                        {post.group}
                      </Badge>
                      <span className="text-sm text-gray-500">• {post.timestamp}</span>
                    </div>

                    <h3 className="text-lg font-semibold mb-2 hover:text-purple-600 cursor-pointer">
                      {post.title}
                    </h3>
                    
                    <p className="text-gray-700 mb-4 line-clamp-2">
                      {post.content}
                    </p>

                    <div className="flex items-center gap-6">
                      <button className="flex items-center gap-2 text-gray-500 hover:text-pink-600 transition-colors">
                        <Heart className="h-5 w-5" />
                        <span className="text-sm">{post.likes}</span>
                      </button>
                      <button className="flex items-center gap-2 text-gray-500 hover:text-purple-600 transition-colors">
                        <MessageCircle className="h-5 w-5" />
                        <span className="text-sm">{post.replies} replies</span>
                      </button>
                    </div>
                  </div>
                </div>
              </Card>
            ))
          ) : (
            <div className="text-center py-16">
              <MessageCircle className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500 text-lg">Tidak ada post yang ditemukan</p>
            </div>
          )}
        </div>

        {/* Community Stats */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="p-6 text-center">
            <div className="text-2xl font-bold text-purple-600">{forumPosts.length}</div>
            <p className="text-sm text-gray-600 mt-1">Diskusi Aktif</p>
          </Card>
          <Card className="p-6 text-center">
            <div className="text-2xl font-bold text-pink-600">
              {forumPosts.reduce((sum, p) => sum + p.replies, 0)}
            </div>
            <p className="text-sm text-gray-600 mt-1">Total Replies</p>
          </Card>
          <Card className="p-6 text-center">
            <div className="text-2xl font-bold text-blue-600">
              {forumPosts.reduce((sum, p) => sum + p.likes, 0)}
            </div>
            <p className="text-sm text-gray-600 mt-1">Total Likes</p>
          </Card>
          <Card className="p-6 text-center">
            <div className="text-2xl font-bold text-green-600">{groups.length - 1}</div>
            <p className="text-sm text-gray-600 mt-1">K-Pop Groups</p>
          </Card>
        </div>
      </div>
    </div>
  );
}
