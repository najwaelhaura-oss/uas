import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Package, MapPin, Truck, CheckCircle, Clock, Search } from 'lucide-react';

interface TrackingStep {
  status: string;
  location: string;
  timestamp: string;
  description: string;
  completed: boolean;
}

export function TrackingPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const orderFromParams = searchParams.get('order');
  
  const [orderNumber, setOrderNumber] = useState(orderFromParams || '');
  const [tracking, setTracking] = useState<TrackingStep[] | null>(orderFromParams ? getMockTracking() : null);

  function getMockTracking(): TrackingStep[] {
    return [
      {
        status: 'Pesanan Selesai',
        location: 'Alamat Penerima',
        timestamp: new Date(Date.now() - 0 * 60 * 60 * 1000).toLocaleString('id-ID'),
        description: 'Paket telah diterima oleh penerima',
        completed: false
      },
      {
        status: 'Dalam Pengiriman',
        location: 'Jakarta Selatan - Kurir',
        timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000).toLocaleString('id-ID'),
        description: 'Paket sedang dalam perjalanan menuju alamat tujuan',
        completed: true
      },
      {
        status: 'Tiba di Hub Terakhir',
        location: 'Jakarta Selatan Distribution Center',
        timestamp: new Date(Date.now() - 18 * 60 * 60 * 1000).toLocaleString('id-ID'),
        description: 'Paket telah tiba di pusat distribusi terakhir',
        completed: true
      },
      {
        status: 'Dalam Transit',
        location: 'Jakarta Pusat Sorting Center',
        timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toLocaleString('id-ID'),
        description: 'Paket sedang dalam proses pengiriman antar kota',
        completed: true
      },
      {
        status: 'Diproses oleh Kurir',
        location: 'K-PopVerse Warehouse',
        timestamp: new Date(Date.now() - 48 * 60 * 60 * 1000).toLocaleString('id-ID'),
        description: 'Paket telah dikemas dan diserahkan ke kurir',
        completed: true
      },
      {
        status: 'Pesanan Dikonfirmasi',
        location: 'K-PopVerse',
        timestamp: new Date(Date.now() - 72 * 60 * 60 * 1000).toLocaleString('id-ID'),
        description: 'Pembayaran berhasil dan pesanan sedang diproses',
        completed: true
      }
    ];
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (orderNumber.trim()) {
      setTracking(getMockTracking());
    }
  };

  const getStatusIcon = (index: number) => {
    if (index === 0) return Package;
    if (index === 1) return Truck;
    if (index === 2) return MapPin;
    if (index === 3) return Clock;
    if (index === 4) return Package;
    return CheckCircle;
  };

  const currentStatus = tracking?.[1];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 py-8">
      <div className="container max-w-4xl">
        <h1 className="text-3xl font-bold mb-8">Lacak Pesanan</h1>

        {/* Search Form */}
        <Card className="p-6 mb-8">
          <form onSubmit={handleSearch}>
            <div className="space-y-4">
              <div>
                <Label htmlFor="orderNumber">Nomor Pesanan</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    id="orderNumber"
                    placeholder="Masukkan nomor pesanan (contoh: KPV12345678)"
                    value={orderNumber}
                    onChange={(e) => setOrderNumber(e.target.value)}
                    required
                  />
                  <Button 
                    type="submit" 
                    className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                  >
                    <Search className="h-4 w-4 mr-2" />
                    Lacak
                  </Button>
                </div>
              </div>
              <p className="text-sm text-gray-600">
                Masukkan nomor pesanan yang tercantum di email konfirmasi atau halaman pesanan selesai
              </p>
            </div>
          </form>
        </Card>

        {/* Tracking Results */}
        {tracking && (
          <>
            {/* Current Status Card */}
            <Card className="p-6 mb-8 bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
              <div className="flex items-center gap-4">
                <div className="h-16 w-16 rounded-full bg-white flex items-center justify-center flex-shrink-0">
                  <Truck className="h-8 w-8 text-purple-600" />
                </div>
                <div className="flex-1">
                  <Badge className="mb-2 bg-purple-600">
                    {currentStatus?.status}
                  </Badge>
                  <h2 className="text-xl font-bold mb-1">
                    {currentStatus?.description}
                  </h2>
                  <p className="text-sm text-gray-600">
                    <MapPin className="h-4 w-4 inline mr-1" />
                    {currentStatus?.location}
                  </p>
                  <p className="text-sm text-gray-500 mt-1">
                    {currentStatus?.timestamp}
                  </p>
                </div>
              </div>
            </Card>

            {/* Order Info */}
            <div className="grid md:grid-cols-2 gap-4 mb-8">
              <Card className="p-4">
                <div className="text-sm text-gray-600 mb-1">Nomor Pesanan</div>
                <div className="font-bold">{orderNumber}</div>
              </Card>
              <Card className="p-4">
                <div className="text-sm text-gray-600 mb-1">Estimasi Tiba</div>
                <div className="font-bold text-green-600">
                  {new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toLocaleDateString('id-ID', {
                    weekday: 'long',
                    day: 'numeric',
                    month: 'long'
                  })}
                </div>
              </Card>
            </div>

            {/* Timeline */}
            <Card className="p-6">
              <h3 className="text-xl font-bold mb-6">Riwayat Pengiriman</h3>
              <div className="space-y-6">
                {tracking.map((step, index) => {
                  const Icon = getStatusIcon(index);
                  const isLast = index === tracking.length - 1;
                  
                  return (
                    <div key={index} className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div className={`h-10 w-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                          step.completed 
                            ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white' 
                            : 'bg-gray-200 text-gray-400'
                        }`}>
                          <Icon className="h-5 w-5" />
                        </div>
                        {!isLast && (
                          <div className={`w-0.5 h-full min-h-[40px] mt-2 ${
                            step.completed ? 'bg-purple-300' : 'bg-gray-200'
                          }`} />
                        )}
                      </div>
                      
                      <div className="flex-1 pb-6">
                        <div className="flex items-start justify-between gap-4">
                          <div>
                            <h4 className={`font-semibold ${
                              step.completed ? 'text-gray-900' : 'text-gray-400'
                            }`}>
                              {step.status}
                            </h4>
                            <p className={`text-sm mt-1 ${
                              step.completed ? 'text-gray-600' : 'text-gray-400'
                            }`}>
                              {step.description}
                            </p>
                            <p className="text-sm text-gray-500 mt-1 flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              {step.location}
                            </p>
                          </div>
                          <div className={`text-xs whitespace-nowrap ${
                            step.completed ? 'text-gray-500' : 'text-gray-400'
                          }`}>
                            {step.timestamp}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>

            {/* Actions */}
            <div className="mt-8 flex gap-4">
              <Button
                onClick={() => navigate(`/invoice?order=${orderNumber}`)}
                className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                Lihat Invoice
              </Button>
              <Button
                variant="outline"
                onClick={() => navigate('/')}
                className="flex-1"
              >
                Kembali ke Beranda
              </Button>
            </div>
          </>
        )}

        {/* Help Section */}
        {!tracking && (
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Butuh Bantuan?</h3>
            <div className="space-y-3 text-sm text-gray-600">
              <p>• Nomor pesanan dapat ditemukan di email konfirmasi atau halaman pesanan selesai</p>
              <p>• Tracking akan diperbarui secara real-time setiap kali ada perubahan status</p>
              <p>• Estimasi waktu pengiriman adalah 2-4 hari kerja</p>
              <p>• Hubungi customer service jika ada kendala: cs@k-popverse.com atau WhatsApp 0812-3456-7890</p>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
